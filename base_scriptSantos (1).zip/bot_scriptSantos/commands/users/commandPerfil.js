exports.commandPerfil = async (sock, participant,userName, enviarImagemUrl) =>{
  try{
    
    var imgPerfil = await sock.profilePictureUrl(participant, "image")
    
  }catch(error){
    console.log(error)
    var imgPerfil = "https://telegra.ph/file/b5427ea4b8701bc47e751.jpg"
  }
  
  textPerfil = `Nome: ${userName}`
  
  await enviarImagemUrl(imgPerfil, textPerfil)
  
  
}