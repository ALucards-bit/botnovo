const { BOT_PHONE} = require("../../settings.json")

exports.commandBan = async(isAdmin, isBotAdmin, userMention, enviarMensagem, isOwnerGroup, participant, sock, from) =>{
  
  if(!isAdmin){
    enviarMensagem("Somente adms podem usar!")
    return
  }
  
  if(!isBotAdmin){
    enviarMensagem("Eu preciso ser adm!!!")
    return
  }
  
  if(!userMention){
    enviarMensagem("Marque um usuario!")
    return
  }
  
  if(userMention.includes(BOT_PHONE)){
    enviarMensagem("vc nao pode me remover")
    return
  }
  
  if(userMention == participant){
    enviarMensagem("Ue, vc quer q eu remova vc?")
    return
  }
  
  if(userMention == isOwnerGroup){
    enviarMensagem("Nao vou remover o criador do grupo")
    return
  }
  
  await sock.groupParticipantsUpdate(
    from,
    [userMention],
    "remove"
  )
  
  await enviarMensagem("Usuario removido com sucesso!")
  
}