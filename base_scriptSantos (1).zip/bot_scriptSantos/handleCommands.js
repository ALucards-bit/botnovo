const { extractMessages } = require("./extractMessages.js");
const { setupMessagingServices } = require("./messagingServices/setupMessagingServices.js");
const { menuCaption } = require("./features/menuCaption.js");
const { verifyPermissions } = require("./verifyPermissions.js");
const {contarMensagem } = require("./mensagens/contarMensagem.js");
const fs = require("fs");

const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  prepareWAMessageMedia
} = require("@whiskeysockets/baileys");

exports.handleCommands = async (sock) => {
  sock.ev.on("messages.upsert", async ({ messages }) => {
    const messageDetails = messages[0];

    if (!messageDetails.message) return;

    const { finalMessageText, from, isCommand, commandName, args, userName, participant, userMention, numberUserMention } = await extractMessages(messageDetails);

    const { reagir, enviarAudioGravacao, enviarImagem, enviarMensagem, enviarImagemUrl, enviarGifUrl } = setupMessagingServices(sock, from, messageDetails);
    
    const searchUserLogin = await contarMensagem(messageDetails, from, participant)

    try {
      
      switch (commandName) {
        
        case "login":
          const { commandLogin } = require("./commands/users/commandLogin.js")
          await commandLogin(searchUserLogin, enviarMensagem, args, from, participant, reagir);
          break
        
        case "menu":
        case "help":
          if(!searchUserLogin){
            await enviarMensagem("Por favor, se registre para usar meus comandos!")
            return
          }
          enviarImagem("assets/imagens/menu.jpg", menuCaption(userName));
          break;

        case "beijar":
          if(!searchUserLogin){
            await enviarMensagem("Por favor, se registre para usar meus comandos!")
            return
          }
          if (!userMention) {
            enviarMensagem("Marque alguém");
            return;
          }

          if (userMention == participant) {
            enviarMensagem("Você não pode se beijar");
            return;
          }

          const textBeijo = `Woww você deu um beijo gostoso no @${numberUserMention}!\n Que apaixonanteeee`;

          enviarGifUrl("https://telegra.ph/file/c9b5ed858237ebc9f7356.mp4", textBeijo, [userMention]);
          break;

        case "advn":
        case "adivinhar":
          if(!searchUserLogin){
            await enviarMensagem("Por favor, se registre para usar meus comandos!")
            return
          }
          if (args < 1 || args > 10) {
            await enviarMensagem("Você precisa digitar um número de 1 a 10");
            return;
          }
          const numberAdivinhe = Math.floor(Math.random() * 10) + 1;
          if (numberAdivinhe == args) {
            await enviarMensagem(`Parabéns ${userName}, você acertou! O número correto era: ${numberAdivinhe}`);
          } else {
            await enviarMensagem(`Que pena, você errou! O número correto era: ${numberAdivinhe}`);
          }
          break;

        case "cep":
          if(!searchUserLogin){
            await enviarMensagem("Por favor, se registre para usar meus comandos!")
            return
          }
          const { commandCep } = require("./commands/users/commandCep.js");
          await commandCep(args, enviarMensagem);
          break;

        case "me":
        case "perfil":
          if(!searchUserLogin){
            await enviarMensagem("Por favor, se registre para usar meus comandos!")
            return
          }
          const { commandPerfil } = require("./commands/users/commandPerfil");
          await commandPerfil(sock, participant, userName, enviarImagemUrl);
          break;

        case "ban":
        case "remover":
          const { isAdmin, isBotAdmin, isOwnerGroup } = await verifyPermissions(sock, from, participant) || {};
          const { commandBan } = require("./commands/admin/commandBan.js");
          await commandBan(isAdmin, isBotAdmin, userMention, enviarMensagem, isOwnerGroup, participant, sock, from);
          break;
          
          
          case "carta":
            case "correio":
              
              if(!args.includes("/")){
                await enviarMensagem("Separe o texto e o numero com uma barra!")
                return
              }
              
              let number = args.split("/")[0];
              
              number = number.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
              
              let texto = args.indexOf("/");
              
              texto = args.substring(texto + 1);
              
              mensagem = `Voce recebeu uma mensagem anonima!\n~${texto}`
              
              await sock.sendMessage(number, {text: mensagem})
              
              await enviarMensagem("Mensagem anonima enviada com sucesso!")
              break
        
        
        case "ping":
          const uptime = process.uptime()
          const hours = Math.floor(uptime / 3600)
           const minutes = Math.floor((uptime % 3600)/ 60)
          const seconds = Math.floor(uptime % 60)
          
          let latency = Math.abs((Date.now() / 1000 )- messageDetails.messageTimestamp)
          
          textPing = `*Latencia*: ${String(latency.toFixed(3))}\n*Ativo ha*: ${hours}h ${minutes}m ${seconds}s`
          await reagir("⚡")
          enviarMensagem(textPing)
          break
          
          
          case "deletar":
            {
              const { isAdmin, isBotAdmin, isOwnerGroup } = await verifyPermissions(sock, from, participant) || {};
              
              if(!isAdmin){
                enviarMensagem("voce precisa ser adm")
                return
              }
              
            if(!isBotAdmin){
              enviarMensagem("O bot precisa ser adm")
              return
            }
          
        sock.sendMessage(from, { delete: { remoteJid: from, fromeMe: false, id: messageDetails.message.extendedTextMessage.contextInfo.stanzaId, participant: messageDetails.message.extendedTextMessage.contextInfo.participant } })  
            }
            break
          
      }
    } catch (error) {
      console.log("Ocorreu um erro:", error);
    }
  });
};

