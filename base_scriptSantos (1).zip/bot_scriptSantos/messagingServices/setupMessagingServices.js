const fs = require("fs")

exports.setupMessagingServices = (sock, from, messageDetails) =>{
  
  const enviarAudioGravacao = async(arquivo) =>{
    await sock.sendMessage(from,{ audio: fs.readFileSync(arquivo), mimetype: "audio/mp4", ptt: true }, {quoted: messageDetails})
  }
  
  const enviarImagem = async(arquivo, text) =>{
    await sock.sendMessage(from,{ image: fs.readFileSync(arquivo), caption: text },{quoted: messageDetails})
  }
  
  const enviarImagemUrl = async(URL, text) =>{
    await sock.sendMessage(from,{ image: {url: URL}, caption: text },{quoted: messageDetails})
  }
  
  const enviarMensagem = async (text, mention) =>{
    await sock.sendMessage(from, {text: `${text}` , mentions: mention}, {quoted: messageDetails})
  }
  
  const enviarGifUrl = async (URL, text, mention=[]) =>{
    await sock.sendMessage(from, {video: {url: URL}, caption: text, mentions: mention, gifPlayback: true }, {quoted: messageDetails})
  }

const reagir = async (emoji) =>{
  await sock.sendMessage(from,{
    react:{
      text: emoji,
      key: messageDetails.key
    }
  })
}
  
  
  return{
    reagir,
    enviarAudioGravacao,
    enviarImagem,
    enviarMensagem,
    enviarImagemUrl,
    enviarGifUrl
  }
  
}